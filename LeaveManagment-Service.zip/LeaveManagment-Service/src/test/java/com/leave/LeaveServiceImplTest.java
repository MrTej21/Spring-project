package com.leave;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.leave.dto.EmployeeLeaveDto;
import com.leave.entity.Holiday;
import com.leave.entity.Leave;
import com.leave.repository.HolidayRepository;
import com.leave.repository.LeaveRepository;
import com.leave.service.LeaveServiceImpl;

class LeaveServiceImplTest {

    @Mock
    private LeaveRepository leaveRepository;

    @Mock
    private HolidayRepository holidayRepository;

    @InjectMocks
    private LeaveServiceImpl leaveService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllLeaves() {
        Leave leave1 = new Leave();
        Leave leave2 = new Leave();
        when(leaveRepository.findAll()).thenReturn(Arrays.asList(leave1, leave2));

        List<Leave> leaves = leaveService.getAllLeaves();
        assertEquals(2, leaves.size());
        verify(leaveRepository, times(1)).findAll();
    }

    @Test
    void testApplyLeave() {
        EmployeeLeaveDto leavedto = new EmployeeLeaveDto();
        Leave leave = new Leave();
        when(leaveRepository.save(any(Leave.class))).thenReturn(leave);

        Leave savedLeave = leaveService.applyLeave(leavedto);
        assertNotNull(savedLeave);
        verify(leaveRepository, times(1)).save(any(Leave.class));
    }


    @Test
    void testCancelLeave() {
        int leaveId = 1;
        doNothing().when(leaveRepository).deleteById(leaveId);

        leaveService.cancelLeave(leaveId);
        verify(leaveRepository, times(1)).deleteById(leaveId);
    }

    @Test
    void testViewHolidayList() {
        Holiday holiday1 = new Holiday();
        Holiday holiday2 = new Holiday();
        when(holidayRepository.findAll()).thenReturn(Arrays.asList(holiday1, holiday2));

        List<Holiday> holidays = leaveService.viewHolidayList();
        assertEquals(2, holidays.size());
        verify(holidayRepository, times(1)).findAll();
    }

    @Test
    void testUpdateLeave() {
        int leaveId = 1;
        Leave leave = new Leave();
        leave.setStartDate(LocalDate.of(2024, 9, 15));
        leave.setEndDate(LocalDate.of(2024, 9, 20));
        leave.setReason("Medical leave");

        Leave existingLeave = new Leave();
        existingLeave.setLeaveID(leaveId); // Ensure the ID is set

        when(leaveRepository.findById(leaveId)).thenReturn(Optional.of(existingLeave));
        when(leaveRepository.save(existingLeave)).thenReturn(existingLeave);

        Leave updatedLeave = leaveService.updateLeave(leaveId, leave);
        assertNotNull(updatedLeave);
        assertEquals(LocalDate.of(2024, 9, 15), updatedLeave.getStartDate());
        assertEquals(LocalDate.of(2024, 9, 20), updatedLeave.getEndDate());
        assertEquals("Medical leave", updatedLeave.getReason());
        verify(leaveRepository, times(1)).findById(leaveId);
        verify(leaveRepository, times(1)).save(existingLeave);
    }


    @Test
    void testGetLeaveById() {
        int leaveId = 1;
        Leave leave = new Leave();
        when(leaveRepository.findById(leaveId)).thenReturn(Optional.of(leave));

        Leave foundLeave = leaveService.getLeaveById(leaveId);
        assertNotNull(foundLeave);
        verify(leaveRepository, times(1)).findById(leaveId);
    }

    @Test
    void testAddHoliday() {
        Holiday holiday = new Holiday();
        when(holidayRepository.save(any(Holiday.class))).thenReturn(holiday);

        Holiday savedHoliday = leaveService.addHoliday(holiday);
        assertNotNull(savedHoliday);
        verify(holidayRepository, times(1)).save(holiday);
    }

    @Test
    void testDeleteHoliday() {
        int holidayId = 1;
        doNothing().when(holidayRepository).deleteById(holidayId);

        leaveService.deleteHoliday(holidayId);
        verify(holidayRepository, times(1)).deleteById(holidayId);
    }

    @Test
    void testUpdateHoliday() {
        int holidayId = 1;
        Holiday holiday = new Holiday();
        holiday.setHolidayDate(LocalDate.of(2024, 12, 25));
        holiday.setHolidayName("Christmas");

        Holiday existingHoliday = new Holiday();
        existingHoliday.setHolidayId(holidayId); // Ensure the ID is set

        when(holidayRepository.findById(holidayId)).thenReturn(Optional.of(existingHoliday));
        when(holidayRepository.save(existingHoliday)).thenReturn(existingHoliday);

        Holiday updatedHoliday = leaveService.updateHoliday(holidayId, holiday);
        assertNotNull(updatedHoliday);
        assertEquals(LocalDate.of(2024, 12, 25), updatedHoliday.getHolidayDate());
        assertEquals("Christmas", updatedHoliday.getHolidayName());
        verify(holidayRepository, times(1)).findById(holidayId);
        verify(holidayRepository, times(1)).save(existingHoliday);
    }

}

