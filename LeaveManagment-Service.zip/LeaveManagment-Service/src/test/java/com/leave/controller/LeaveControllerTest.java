package com.leave.controller;

import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.leave.entity.Holiday;
import com.leave.entity.Leave;
import com.leave.service.LeaveService;

public class LeaveControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LeaveService leaveService;

    @InjectMocks
    private LeaveController leaveController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(leaveController).build();
    }

    @Test
    public void testGetAllLeaves() throws Exception {
        List<Leave> leaves = Arrays.asList(new Leave(), new Leave());
        when(leaveService.getAllLeaves()).thenReturn(leaves);

        mockMvc.perform(MockMvcRequestBuilders.get("/leaves/getAllleaves"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(leaves.size()));

        verify(leaveService, times(1)).getAllLeaves();
    }

    @Test
    public void testApplyLeave() throws Exception {
        Leave leave = new Leave();
        when(leaveService.applyLeave(leave)).thenReturn(leave);

        mockMvc.perform(MockMvcRequestBuilders.post("/leaves/apply")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1,\"name\":\"Test Leave\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));

        verify(leaveService, times(1)).applyLeave(leave);
    }

    @Test
    public void testCancelLeave() throws Exception {
        int id = 1;

        mockMvc.perform(MockMvcRequestBuilders.delete("/leaves/cancel/{id}", id))
                .andExpect(MockMvcResultMatchers.status().isOk());

        verify(leaveService, times(1)).cancelLeave(id);
    }

    @Test
    public void testViewHolidayList() throws Exception {
        List<Holiday> holidays = Arrays.asList(new Holiday(), new Holiday());
        when(leaveService.viewHolidayList()).thenReturn(holidays);

        mockMvc.perform(MockMvcRequestBuilders.get("/leaves/holidays"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.length()").value(holidays.size()));

        verify(leaveService, times(1)).viewHolidayList();
    }

    @Test
    public void testUpdateLeave() throws Exception {
        int id = 1;
        Leave leave = new Leave();
        when(leaveService.updateLeave(id, leave)).thenReturn(leave);

        mockMvc.perform(MockMvcRequestBuilders.put("/leaves/update/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1,\"name\":\"Updated Leave\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));

        verify(leaveService, times(1)).updateLeave(id, leave);
    }

    @Test
    public void testGetLeaveById() throws Exception {
        int id = 1;
        Leave leave = new Leave();
        when(leaveService.getLeaveById(id)).thenReturn(leave);

        mockMvc.perform(MockMvcRequestBuilders.get("/leaves/leave/{id}", id))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));

        verify(leaveService, times(1)).getLeaveById(id);
    }

    @Test
    public void testAddHoliday() throws Exception {
        Holiday holiday = new Holiday();
        when(leaveService.addHoliday(holiday)).thenReturn(holiday);

        mockMvc.perform(MockMvcRequestBuilders.post("/leaves/holiday")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1,\"name\":\"New Holiday\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));

        verify(leaveService, times(1)).addHoliday(holiday);
    }

    @Test
    public void testDeleteHoliday() throws Exception {
        int id = 1;

        mockMvc.perform(MockMvcRequestBuilders.delete("/leaves/holiday/{id}", id))
                .andExpect(MockMvcResultMatchers.status().isOk());

        verify(leaveService, times(1)).deleteHoliday(id);
    }

    @Test
    public void testUpdateHoliday() throws Exception {
        int id = 1;
        Holiday holiday = new Holiday();
        when(leaveService.updateHoliday(id, holiday)).thenReturn(holiday);

        mockMvc.perform(MockMvcRequestBuilders.put("/leaves/holiday/{id}", id)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"id\":1,\"name\":\"Updated Holiday\"}"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(1));

        verify(leaveService, times(1)).updateHoliday(id, holiday);
    }
}
