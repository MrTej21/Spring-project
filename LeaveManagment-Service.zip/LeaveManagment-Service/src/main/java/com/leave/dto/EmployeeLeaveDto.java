package com.leave.dto;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

import jakarta.validation.Valid;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Component
@Valid
public class EmployeeLeaveDto {
	
	@NotNull(message = "EmployeeId is required")
    private int employeeID;
	
	@NotNull(message = "LeaveType is required")
	@Size(max = 50,message = "Leave type should not exceed 50 characters")
    private String leaveType;
	
	@NotNull(message = "Startdate is required")
	@FutureOrPresent(message = "startdate must be in the present or future")
    private LocalDate startDate;
	
	@NotNull(message = "enddate is required")
	@FutureOrPresent(message = "enddate must be in the present or future")
    private LocalDate endDate;
	
	@NotBlank(message = "reason is required")
    private String Reason;

}
