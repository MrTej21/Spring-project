package com.leave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaveManagmentServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(LeaveManagmentServiceApplication.class, args);
    }
}
 