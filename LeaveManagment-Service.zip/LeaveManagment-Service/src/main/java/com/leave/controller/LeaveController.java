package com.leave.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.leave.dto.EmployeeLeaveDto;
import com.leave.entity.Holiday;
import com.leave.entity.Leave;
import com.leave.service.LeaveService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/leaves")
@Valid
public class LeaveController {

    @Autowired
    private LeaveService leaveService;
    
    @Autowired
    private EmployeeLeaveDto employeeLeaveDto;
    
    private static final Logger logger = LoggerFactory.getLogger(LeaveController.class);
    
    @GetMapping("/getAllleaves") 
    public ResponseEntity<List<Leave>> getAllLeaves() {
        logger.info("Fetching all leave records.");
        List<Leave> leaves = leaveService.getAllLeaves();
        return new ResponseEntity<>(leaves, HttpStatus.OK);
    }

    @PostMapping("/apply")
    public ResponseEntity<Leave> applyLeave(@Valid @RequestBody EmployeeLeaveDto leaveDto) {
        logger.info("Applying for leave: {}", leaveDto);
        Leave leave = leaveService.applyLeave(leaveDto);
        return new ResponseEntity<>(leave, HttpStatus.CREATED);
    }

    @DeleteMapping("/cancel/{leaveid}")
    public ResponseEntity<Void> cancelLeave(@PathVariable int id) {
        logger.info("Cancelling leave with ID: {}", id);
        leaveService.cancelLeave(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/holidays")
    public ResponseEntity<List<Holiday>> viewHolidayList() {
        logger.info("Fetching holiday list.");
        List<Holiday> holidays = leaveService.viewHolidayList();
        return new ResponseEntity<>(holidays, HttpStatus.OK);
    }
    
    @PutMapping("/update/{leaveid}")
    public ResponseEntity<Leave> updateLeave(@PathVariable int id, @Valid @RequestBody EmployeeLeaveDto leaveDto) {
        logger.info("Updating leave with ID: {}", id);
        Leave updatedLeave = leaveService.updateLeave(id, leaveDto);
        return new ResponseEntity<>(updatedLeave, HttpStatus.OK);
    }

    @GetMapping("/leave/{leaveid}")
    public ResponseEntity<Leave> getLeaveById(@PathVariable int id) {
        logger.info("Fetching leave record with ID: {}", id);
        Leave leave = leaveService.getLeaveById(id);
        return new ResponseEntity<>(leave, HttpStatus.OK);
    }

    @PostMapping("/holiday")
    public ResponseEntity<Holiday> addHoliday(@Valid @RequestBody Holiday holiday) {
        logger.info("Adding new holiday: {}", holiday);
        Holiday newHoliday = leaveService.addHoliday(holiday);
        return new ResponseEntity<>(newHoliday, HttpStatus.CREATED);
    }

    @DeleteMapping("/holiday/{deleteholidayid}")
    public ResponseEntity<Void> deleteHoliday(@PathVariable int id) {
        logger.info("Deleting holiday with ID: {}", id);
        leaveService.deleteHoliday(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/holiday/{updateholidayid}")
    public ResponseEntity<Holiday> updateHoliday(@PathVariable int id, @Valid @RequestBody Holiday holiday) {
        logger.info("Updating holiday with ID: {}", id);
        Holiday updatedHoliday = leaveService.updateHoliday(id, holiday);
        return new ResponseEntity<>(updatedHoliday, HttpStatus.OK);
    }
    @GetMapping("/approveOrRejectLeave/{leaveId}/{status}")
    public ResponseEntity<String> approveOrRejectLeave(@PathVariable("leaveId") int leaveId, @PathVariable("status") String status){
    	String st =leaveService.approveOrRejectLeave(leaveId,status);
    	return new ResponseEntity<>(st,HttpStatus.OK);
    	
    }
}
