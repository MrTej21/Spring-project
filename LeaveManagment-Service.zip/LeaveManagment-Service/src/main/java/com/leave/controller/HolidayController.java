package com.leave.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.leave.entity.Holiday;
import com.leave.service.LeaveService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/Holidays")
public class HolidayController {
	
	@Autowired
	private LeaveService leaveService;
	
	private static final Logger logger = LoggerFactory.getLogger(HolidayController.class);
	
	 @PostMapping("/addholiday")
	    public ResponseEntity<Holiday> addHoliday(@Valid @RequestBody Holiday holiday) {
	        logger.info("Adding new holiday: {}", holiday);
	        Holiday newHoliday = leaveService.addHoliday(holiday);
	        return new ResponseEntity<>(newHoliday, HttpStatus.CREATED);
	    }
	 
	 @DeleteMapping("/delete/{id}")
	    public ResponseEntity<Void> deleteHoliday(@PathVariable int id) {
	        logger.info("Deleting holiday with ID: {}", id);
	        leaveService.deleteHoliday(id);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }
	 
	 @PutMapping("/update/{id}")
	    public ResponseEntity<Holiday> updateHoliday(@PathVariable int id, @Valid @RequestBody Holiday holiday) {
	        logger.info("Updating holiday with ID: {}", id);
	        Holiday updatedHoliday = leaveService.updateHoliday(id, holiday);
	        return new ResponseEntity<>(updatedHoliday, HttpStatus.OK);
	    }
	
	 @GetMapping("/holidaysList")
	    public ResponseEntity<List<Holiday>> viewHolidayList() {
	        logger.info("Fetching holiday list.");
	        List<Holiday> holidays = leaveService.viewHolidayList();
	        return new ResponseEntity<>(holidays, HttpStatus.OK);
	    }
	 
	    

}
