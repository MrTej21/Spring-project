package com.leave.service;

import java.util.List;

import com.leave.dto.EmployeeLeaveDto;
import com.leave.entity.Holiday;
import com.leave.entity.Leave;

import jakarta.validation.Valid;

public interface LeaveService {
	
	List<Leave> getAllLeaves();

    //Leave applyLeave(Leave leave);
    void cancelLeave(int id);
	List<Holiday> viewHolidayList();
	Holiday updateHoliday(int id, Holiday holiday);
	void deleteHoliday(int id);
	Holiday addHoliday(Holiday holiday);
	Leave getLeaveById(int id);
	//Leave updateLeave(int id, Leave leave);

	Leave applyLeave(EmployeeLeaveDto leave);

	Leave updateLeave(int id, @Valid EmployeeLeaveDto leave);

	String approveOrRejectLeave(int leaveId, String status);

}
