package com.leave.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.leave.dto.EmployeeLeaveDto;
import com.leave.entity.Holiday;
import com.leave.entity.Leave;
import com.leave.exception.ResourceNotFoundException;
import com.leave.repository.HolidayRepository;
import com.leave.repository.LeaveRepository;

@Service
public class LeaveServiceImpl implements LeaveService {

    private static final Logger log = LoggerFactory.getLogger(LeaveServiceImpl.class);

    @Autowired
    private LeaveRepository lr;

    @Autowired
    private HolidayRepository hr;

    @Override
    public List<Leave> getAllLeaves() {
        log.info("Fetching all leaves");
        return lr.findAll();
    }

    @Override
    public Leave applyLeave(EmployeeLeaveDto leaveDto) {
        log.info("Applying leave for employeeID: {}", leaveDto.getEmployeeID());
        Leave leave = new Leave();
        leave.setEmployeeID(leaveDto.getEmployeeID());
        leave.setLeaveType(leaveDto.getLeaveType());
        leave.setStartDate(leaveDto.getStartDate());
        leave.setEndDate(leaveDto.getEndDate());
        leave.setReason(leaveDto.getReason());
        leave.setAppliedDate(LocalDate.now());

        // Check if the leave type is "Optional Holiday" and if the start date matches an optional holiday
        if ("Optional Holiday".equalsIgnoreCase(leaveDto.getLeaveType()) && isOptionalHoliday(leaveDto.getStartDate())) {
            leave.setStatus("Approved");
            log.info("Leave automatically approved for optional holiday on: {}", leaveDto.getStartDate());
        } else {
            leave.setStatus("Pending");
        }

        log.info("Leave details: {}", leave);
        return lr.save(leave);
    }

    private boolean isOptionalHoliday(LocalDate startDate) {
        List<Holiday> optionalHolidays = hr.findAll();
        return optionalHolidays.stream()
                .anyMatch(holiday -> holiday.getHolidayDate().equals(startDate));
    }


    @Override
    public void cancelLeave(int id) {
        log.info("Canceling leave with ID: {}", id);
        lr.deleteById(id);
    }

    @Override
    public List<Holiday> viewHolidayList() {
        log.info("Fetching holiday list");
        return hr.findAll();
    }

    public Leave updateLeave(int id, Leave leave) {
        log.info("Updating leave with ID: {}", id);
        Leave existingLeave = lr.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave not found"));
        existingLeave.setStartDate(leave.getStartDate());
        existingLeave.setEndDate(leave.getEndDate());
        existingLeave.setReason(leave.getReason());
        return lr.save(existingLeave);
    }

    public Leave getLeaveById(int id) {
        log.info("Fetching leave with ID: {}", id);
        return lr.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave not found"));
    }

    public Holiday addHoliday(Holiday holiday) {
        log.info("Adding holiday: {}", holiday);
        return hr.save(holiday);
    }

    public void deleteHoliday(int id) {
        log.info("Deleting holiday with ID: {}", id);
        hr.deleteById(id);
    }

    public Holiday updateHoliday(int id, Holiday holiday) {
        log.info("Updating holiday with ID: {}", id);
        Holiday existingHoliday = hr.findById(id).orElseThrow(() -> new ResourceNotFoundException("Holiday not found"));
        existingHoliday.setHolidayDate(holiday.getHolidayDate());
        existingHoliday.setHolidayName(holiday.getHolidayName());
        return hr.save(existingHoliday);
    }

    @Override
    public Leave updateLeave(int id, EmployeeLeaveDto leave1) {
        log.info("Updating leave with ID: {}", id);
        Leave existingLeave = lr.findById(id).orElseThrow(() -> new ResourceNotFoundException("Leave not found"));
        BeanUtils.copyProperties(leave1, existingLeave);
        existingLeave.setAppliedDate(LocalDate.now());
        existingLeave.setStatus("Waiting for Approval");
        return lr.save(existingLeave);
    }

    @Override
    public String approveOrRejectLeave(int leaveId, String status) {
        log.info("Approving/Rejecting leave with ID: {}", leaveId);
        Optional<Leave> id = lr.findById(leaveId);
        if (id.isPresent()) {
            id.get().setStatus(status);
            lr.save(id.get());
            return "Leave status is : " + status;
        } else {
            throw new ResourceNotFoundException("Invalid Leave Id");
        }
    }
}
